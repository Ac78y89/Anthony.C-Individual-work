// Adding an event listener for when the DOM content is fully loaded
document.addEventListener("DOMContentLoaded", function () {
  // Getting references to various DOM elements
  const submitButton = document.getElementById("submitBtn");
  const paymentForm = document.getElementById("paymentForm");
  const confirmationDiv = document.getElementById("confirmation");
  const submittedDataDiv = document.getElementById("submittedData");

  // Adding a click event listener to the submit button
  submitButton.addEventListener("click", function () {
    // Getting values from form inputs
    const firstName = document.getElementById("firstName").value;
    const lastName = document.getElementById("lastName").value;
    const email = document.getElementById("email").value;
    const phoneNumber = document.getElementById("phoneNumber").value;

    // Creating an object to store payment data
    const paymentData = {
      firstName: firstName,
      lastName: lastName,
      email: email,
      phoneNumber: phoneNumber,
    };

    // Storing payment data in local storage as a JSON string
    localStorage.setItem("paymentData", JSON.stringify(paymentData));

    // Hiding the payment form and showing the confirmation message
    paymentForm.classList.add("hidden");
    confirmationDiv.classList.remove("hidden");

    // Displaying the submitted data in a div
    submittedDataDiv.innerHTML = `
      <p><strong>First Name:</strong> ${paymentData.firstName}</p>
      <p><strong>Last Name:</strong> ${paymentData.lastName}</p>
      <p><strong>Email:</strong> ${paymentData.email}</p>
      <p><strong>Phone Number:</strong> ${paymentData.phoneNumber}</p>
    `;
  });
});
