document.getElementById('buyButton').addEventListener('click', function () {
    
    window.location.href = 'habits-payment.html';
});

document.getElementById('viewMore').addEventListener('click', function () {
   
    window.location.href = 'habits-view-more.html';
});

document.getElementById('back').addEventListener('click', function () {
    
    window.location.href = 'home.html';
});