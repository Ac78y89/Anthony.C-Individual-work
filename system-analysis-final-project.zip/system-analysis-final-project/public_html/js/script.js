// Selecting the menu icon and navigation links elements
const menuIcon = document.querySelector('.menu-icon');
const navLinks = document.querySelector('.nav-links');

// Adding a click event listener to the menu icon
menuIcon.addEventListener('click', () => {
  navLinks.classList.toggle('nav-active'); // Toggling the 'nav-active' class to show/hide navigation links
});

// Initializing an index variable for image display
let index = 0;

// Calling the function to display images
displayImages();

// Function to display images
function displayImages() {
  let i;
  const images = document.getElementsByClassName("image"); // Selecting all elements with class 'image'
  
  // Looping through the images and hiding them
  for (i = 0; i < images.length; i++) {
    images[i].style.display = "none";
  }
  
  index++; // Incrementing the index
  
  if (index > images.length) {
    index = 1; // Resetting index when it goes beyond the number of images
  }
  
  images[index - 1].style.display = "block"; // Displaying the current image
  
  setTimeout(displayImages, 2000); // Calling the function again after 2 seconds (slideshow effect)
}
