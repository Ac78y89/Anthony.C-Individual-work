// Adding a click event listener to the 'buyButton' element
document.getElementById('buyButton').addEventListener('click', function () {
  // Redirecting the user to a payment page named "power-payment.html"
  window.location.href = 'power-payment.html';
});

// Adding a click event listener to the 'alternatives' element
document.getElementById('alternatives').addEventListener('click', function () {
  // Redirecting the user to a page for power alternatives named "power-alternatives.html"
  window.location.href = 'power-alternatives.html';
});

// Adding a click event listener to the 'back' element
document.getElementById('back').addEventListener('click', function () {
  // Redirecting the user back to the main index page named "index.html"
  window.location.href = 'index.html';
});

// Adding a click event listener to the 'continue' element
document.getElementById('continue').addEventListener('click', function () {
  // Displaying an alert message upon clicking the 'continue' button
  alert('Thank you for purchasing "The Hunger Games"!');
  // Here, you can implement the logic for actual purchase actions, like redirecting to a payment page.
});
